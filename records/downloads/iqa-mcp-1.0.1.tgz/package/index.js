#!/usr/bin/env node
/**
 * iqa-mcp npm launcher (1.0.1)
 *
 * Spawns the Python iqa-mcp MCP server. The canonical implementation is
 * the Python package `iqa-mcp` on PyPI (pip install iqa-mcp).
 *
 * Server resolution order:
 *   1. IQA_MCP_CMD environment variable (explicit override)
 *   2. an explicit server.py path passed as the first argument
 *   3. the installed `iqa-mcp` console script (pip install iqa-mcp)
 *   4. ./server.py in the current directory (source checkout)
 */
const { spawn, spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

function findConsoleScript() {
  const checker = process.platform === "win32" ? "where" : "which";
  const r = spawnSync(checker, ["iqa-mcp"], { encoding: "utf8" });
  if (r.status === 0) {
    const first = r.stdout.split(/\r?\n/).find(Boolean);
    if (first) return first.trim();
  }
  return null;
}

function pythonCmd() {
  return process.platform === "win32" ? "python" : "python3";
}

function resolveServer() {
  const override = process.env.IQA_MCP_CMD;
  if (override) return { command: override, args: [] };

  if (process.argv[2]) {
    return { command: pythonCmd(), args: [path.resolve(process.argv[2])] };
  }

  const exe = findConsoleScript();
  if (exe) return { command: exe, args: [] };

  const local = path.resolve("server.py");
  if (fs.existsSync(local)) {
    return { command: pythonCmd(), args: [local] };
  }
  return null;
}

const server = resolveServer();
if (!server) {
  console.error("iqa-mcp launcher: cannot locate the server.");
  console.error("Run `pip install iqa-mcp` (recommended), or run from a source");
  console.error("checkout containing server.py, or set IQA_MCP_CMD.");
  console.error("See: https://iqa.org/MCP/");
  process.exit(1);
}

const child = spawn(server.command, server.args, {
  stdio: "inherit",
  env: { ...process.env },
});

child.on("error", (err) => {
  console.error("iqa-mcp launcher: failed to spawn the Python server:", err.message);
  process.exit(1);
});

child.on("exit", (code) => process.exit(code ?? 0));
