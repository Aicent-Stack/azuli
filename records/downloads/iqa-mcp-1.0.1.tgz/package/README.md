# iqa-mcp (npm launcher)

Launcher for the IQA attestation MCP server. Spawns the Python server
that the canonical [`iqa-mcp`](https://pypi.org/project/iqa-mcp/) package
on PyPI installs.

## Install the server

```bash
pip install iqa-mcp
```

## Usage

```bash
npx iqa-mcp
```

Server resolution order: the `IQA_MCP_CMD` environment variable, an
explicit `server.py` path argument, the installed `iqa-mcp` console
script, then `./server.py` in the current directory.

See [iqa.org/MCP](https://iqa.org/MCP/) for the full tool documentation.
