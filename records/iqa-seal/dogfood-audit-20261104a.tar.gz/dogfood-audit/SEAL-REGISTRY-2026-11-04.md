# Dogfood Seal Registry — full verification record

Date: 2026-11-04 · Operator: ShaoBao Li (Lee) / @Aicent-com / RTTP CRI 27 · IQA CRI 28 · Organ: forge / ba92fadd46a51caf…

## Scope sealed and verified

Master ledger `release-attestations.json`: **80 records**, dual-site identical (iqa.org ≡ rttp.com), sha256 `96f329e09251d9eb…`.

| Category | Records | What they bind |
|---|---|---|
| release packages (rttp / iqa-org / @aicent/*) | 18 | PyPI wheels, npm tarballs, crates — versions 1.2.6→1.3.1 |
| iqa-mcp | 14 | PyPI/npm/crates 0.1.0→1.0.2 |
| conformance artifacts | 5 | lra-runner 20261023/-rev-b/-rev-c/-rev3, aae-runner 20261104a |
| I-D documents | 7 | draft-li-rttp-iqa-addressing -00/-01/-02(TXT+tarball), intent-addressing -00/-01, subject-attestation -00 |
| site-freeze pages | 36 | 14 myth sites (+reseal), brief ×4, URI ×4, whitepaper v0.7, conformance 5 pages |

Blog ledger `blog-seals.json`: **87 records** (75 slugs; 12 slugs carry v1+v2 append-only re-seals), dual-site identical, sha256 `48dbe1c81e7dd6d5…`. Digest recipe binds bilingual sources: `sha256(b'aicent-blog-seal-v1\0' + slug + b'\0' + en_source + b'\0' + zh_source)`.

Production organ ledger: **45 subjects** (radiant, forge organ).

## Verification results (2026-11-04 full dogfood run)

1. Envelopes: **80/80 bundle + 87/87 blog** verified (ed25519, forge organ, subject = iqa://<sha[:32]>.forge.iqa). Zero failures.
2. Live artifacts: **80/80 PASS** — every record URL fetched live and byte-compared; site-freeze two-tier (tarball sha + strip-SEAL page digest) all match. Zero failures.
3. Blog source digests: latest-version records **75/75 PASS** recomputed from bilingual sources; 12 v1 records superseded by v2 re-seals (sources revised after v1 — append-only semantics intact, old records preserved).
4. Blog rendered snapshots: PASS=28, DRIFT(WARN, by design — template/artnav ripples after seal)=146, FAIL=0 of 174.
5. Current-release functional self-tests (isolated): rttp 1.3.1 selftest rc=0; iqa-org 1.3.1 selftest **111/111 PASS**; @aicent/rttp 1.3.1 CLI rc=0; wheels/tarballs byte-identical to registries.
6. I-D documents: all 7 draft records fetched live from www.ietf.org, byte-identical.

## Machine-readable registry

`seal-registry.json` in this tarball carries the full record listing (package, version, sha256, tarball sha, URL, rttp address per record).

This registry and report are themselves sealed: bundle record `audit/dogfood-registry@2026-11-04-audit`.
